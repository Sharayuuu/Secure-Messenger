package com.example.section7findfriend.data;

public class Constant {


}
